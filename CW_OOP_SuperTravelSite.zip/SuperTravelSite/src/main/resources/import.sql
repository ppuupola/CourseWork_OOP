insert into user (email, full_name, password, phone, user_group) values ('admin@email.com', 'John Smith', '$2a$12$vSsm0SzJD2FPiCLSuOFmTe4u1i0/BpCaoEBx3oYHAs8pfMpXVSBhG', '+371000000', 0);
insert into user (email, full_name, password, phone, user_group) values ('user@email.com', 'Bob Smith', '$2a$12$vSsm0SzJD2FPiCLSuOFmTe4u1i0/BpCaoEBx3oYHAs8pfMpXVSBhG', '+371000000', 1);

insert into category (title, description, picture_url) values ('Elite', 'Elite trips category', 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Elite_Model_Management_logo.svg/2560px-Elite_Model_Management_logo.svg.png');
insert into category (title, description, picture_url) values ('Economy', 'Economy trips category', 'https://www.thecatalystiq.com/wp-content/uploads/2022/01/global-article-img-.png');

insert into country (title, description, picture_url) values ('Latvia', 'Best country in the world', 'https://www.state.gov/wp-content/uploads/2018/11/Latvia-2107x1406.jpg');

insert into trip (title, category_id, country_id, short_description, long_description, picture_url) values ('Jurmala SPA', 1, 1, 'Best Jurmalas SPA Hotel', 'We offer a wide selection of classical rehabilitation procedures and relaxation packages. Come to enjoy your time', 'https://media.tacdn.com/media/attractions-splice-spp-674x446/06/6f/5e/f1.jpg');

insert into date (trip_id, start_date, end_date, food, price) values (1, '20.05.2022', '27.05.2022', 'INCLUDED', 750);

insert into orders (date_id, user_id, comment) values (1, 2, 'Please contact me between 10 and 14 AM');