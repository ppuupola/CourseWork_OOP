package com.supertravel.Application.model;

import javax.persistence.*;

@Entity
@Table(name = "user")
public class User {
    public enum Group {
        ADMINISTRATOR,
        USER
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false, unique = true)
    public String email;
    @Column(nullable = false)
    public Group userGroup;
    @Column(nullable = false)
    public String fullName;
    @Column(nullable = false)
    public String phone;

    @Column(nullable = false)
    public String password;
}
