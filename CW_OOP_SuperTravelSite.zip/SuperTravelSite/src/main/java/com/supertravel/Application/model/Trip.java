package com.supertravel.Application.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "trip")
public class Trip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public String title;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "country_id", referencedColumnName = "id")
    public Country country;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "category_id", referencedColumnName = "id")
    public Category category;

    @JsonIgnoreProperties({"trip"})
    @OneToMany(mappedBy = "trip")
    public Set<Date> dates;

    @Column(nullable = false)
    public String pictureUrl;
    @Column(length=512)
    public String shortDescription;
    @Column(length=2048)
    public String longDescription;
}
