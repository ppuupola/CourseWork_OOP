package com.supertravel.Application.controller;

import com.supertravel.Application.model.Date;
import com.supertravel.Application.model.Order;
import com.supertravel.Application.model.Trip;
import com.supertravel.Application.model.User;
import com.supertravel.Application.repository.DateRepo;
import com.supertravel.Application.repository.OrderRepo;
import com.supertravel.Application.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

class CreateOrderRequest {
    public Long date;

    public String comment;
}

@Controller
public class OrderController {
    @Autowired
    OrderRepo orderRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    DateRepo dateRepo;


    @GetMapping("/order")
    public ResponseEntity<List<Order>> getOrders(HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        User user = userRepo.findById(userId).get();
        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Iterable<Order> iterable = orderRepo.findAll();
        List<Order> list = Streamable.of(iterable).toList();

        return new ResponseEntity<List<Order>>(list, HttpStatus.OK);
    }

    @GetMapping("/order/{id}")
    public ResponseEntity<Order> getOrder(@PathVariable(value="id") Long id, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        User user = userRepo.findById(userId).get();

        Optional<Order> order = orderRepo.findById(id);
        if (order.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        if (order.get().user.id == user.id || user.userGroup == User.Group.ADMINISTRATOR) {
            return new ResponseEntity<Order>(order.get(), HttpStatus.OK);
        }

        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    @PostMapping("/order")
    public ResponseEntity<String> createOrder(@RequestBody CreateOrderRequest request, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        Order order = new Order();
        order.date = dateRepo.findById(request.date).get();
        order.user = user;
        order.comment = request.comment;

        orderRepo.save(order);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @DeleteMapping("/order")
    public ResponseEntity<String> cancelOrder(
            @RequestParam(value="id") Long id,
            HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();
        Order order = orderRepo.findById(id).get();

        if (order.user.id == user.id) {
            return new ResponseEntity<>("not your order", HttpStatus.FORBIDDEN);
        }

        orderRepo.deleteById(id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }
}
