package com.supertravel.Application.model;

import javax.persistence.*;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @ManyToOne
    @JoinColumn(name="user_id", referencedColumnName = "id", nullable = false)
    public User user;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="date_id", referencedColumnName = "id", nullable = true)
    public Date date;

    @Column(nullable = false, length=1024)
    public String comment;
}
