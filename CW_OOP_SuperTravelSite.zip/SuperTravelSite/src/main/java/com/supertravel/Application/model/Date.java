package com.supertravel.Application.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

@Entity
@Table(name = "date")
public class Date {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @JsonIgnoreProperties({"dates"})
    @ManyToOne
    @JoinColumn(name="trip_id", referencedColumnName = "id")
    public Trip trip;


    @JsonIgnoreProperties({"date", "user"})
    @OneToOne(mappedBy = "date", optional = true)
    private Order order;

    public String startDate;
    public String endDate;
    public String food;
    public Float price;
}
