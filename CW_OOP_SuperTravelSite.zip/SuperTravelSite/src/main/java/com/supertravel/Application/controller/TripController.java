package com.supertravel.Application.controller;

import com.supertravel.Application.model.*;
import com.supertravel.Application.repository.CategoryRepo;
import com.supertravel.Application.repository.CountryRepo;
import com.supertravel.Application.repository.TripRepo;
import com.supertravel.Application.repository.UserRepo;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.persistence.*;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;
import java.util.Set;

class CreateTripRequest {
    public String title;
    public Long country;
    public Long category;
    public String pictureUrl;
    public String shortDescription;
    public String longDescription;
}

class UpdateTripRequest {
    public Long id;
    public String title;
    public Long country;
    public Long category;
    public String pictureUrl;
    public String shortDescription;
    public String longDescription;
}

@Controller
public class TripController {
    @Autowired
    TripRepo tripRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    CountryRepo countryRepo;
    @Autowired
    CategoryRepo categoryRepo;

    @GetMapping("/trip")
    public ResponseEntity<List<Trip>> getTrips() {
        Iterable<Trip> iterable = tripRepo.findAll();
        List<Trip> list = Streamable.of(iterable).toList();

        return new ResponseEntity<List<Trip>>(list, HttpStatus.OK);
    }

    @GetMapping("/trip/{id}")
    public ResponseEntity<Trip> getTrip(@PathVariable(value="id") Long id) {
        Optional<Trip> trip = tripRepo.findById(id);
        if (trip.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return new ResponseEntity<Trip>(trip.get(), HttpStatus.OK);
    }

    @PostMapping("/trip")
    public ResponseEntity<String> createTrip(@RequestBody CreateTripRequest request, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can create new trip", HttpStatus.FORBIDDEN);
        }

        Trip trip = new Trip();
        trip.country = countryRepo.findById(request.country).get();
        trip.category = categoryRepo.findById(request.category).get();
        trip.title = request.title;
        trip.pictureUrl = request.pictureUrl;
        trip.shortDescription = request.shortDescription;
        trip.longDescription = request.longDescription;

        tripRepo.save(trip);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @PutMapping("/trip")
    public ResponseEntity<String> updateTrip(
        @RequestBody UpdateTripRequest request,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can uptrip a trip", HttpStatus.FORBIDDEN);
        }

        if (request.id == null) {
            return new ResponseEntity<>("no trip id provided", HttpStatus.BAD_REQUEST);
        }

        Trip trip = tripRepo.findById(request.id).get();
        trip.pictureUrl = request.pictureUrl;
        trip.title = request.title;
        trip.category = categoryRepo.findById(request.category).get();
        trip.country = countryRepo.findById(request.country).get();
        trip.shortDescription = request.shortDescription;
        trip.longDescription = request.longDescription;

        tripRepo.save(trip);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @DeleteMapping("/trip")
    public ResponseEntity<String> deleteTrip(
        @RequestParam(value="id") Long id,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can delete a trip", HttpStatus.FORBIDDEN);
        }

        tripRepo.deleteById(id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }
}
