package com.supertravel.Application.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "country")
public class Country {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    public String title;
    public String pictureUrl;
    @Column(length=512)
    public String description;

    @OneToMany(mappedBy = "country")
    private Set<Trip> trips;
}
