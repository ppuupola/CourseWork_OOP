package com.supertravel.Application.controller;

import com.supertravel.Application.model.Date;
import com.supertravel.Application.model.User;
import com.supertravel.Application.repository.DateRepo;
import com.supertravel.Application.repository.TripRepo;
import com.supertravel.Application.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

class CreateDateRequest {
    public Long trip;
    public String startDate;
    public String endDate;
    public String food;
    public Float price;
}

class UpdateDateRequest {
    public Long id;
    public Long trip;
    public String startDate;
    public String endDate;
    public String food;
    public Float price;
}

@Controller
public class DateController {
    @Autowired
    DateRepo dateRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    TripRepo tripRepo;

    @GetMapping("/date")
    public ResponseEntity<List<Date>> getCategories() {
        Iterable<Date> iterable = dateRepo.findAll();
        List<Date> list = Streamable.of(iterable).toList();

        return new ResponseEntity<List<Date>>(list, HttpStatus.OK);
    }

    @GetMapping("/date/{id}")
    public ResponseEntity<Date> getDate(@PathVariable(value="id") Long id) {
        Optional<Date> date = dateRepo.findById(id);
        if (date.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return new ResponseEntity<Date>(date.get(), HttpStatus.OK);
    }

    @PostMapping("/date")
    public ResponseEntity<String> createDate(@RequestBody CreateDateRequest request, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can create new date", HttpStatus.FORBIDDEN);
        }

        Date date = new Date();
        date.trip = tripRepo.findById(request.trip).get();
        date.startDate = request.startDate;
        date.endDate = request.endDate;
        date.food = request.food;
        date.price = request.price;

        dateRepo.save(date);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @PutMapping("/date")
    public ResponseEntity<String> updateDate(
        @RequestBody UpdateDateRequest request,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can update a date", HttpStatus.FORBIDDEN);
        }

        if (request.id == null) {
            return new ResponseEntity<>("no date id provided", HttpStatus.BAD_REQUEST);
        }

        Date date = dateRepo.findById(request.id).get();
        date.trip = tripRepo.findById(request.trip).get();
        date.startDate = request.startDate;
        date.endDate = request.endDate;
        date.food = request.food;
        date.price = request.price;

        dateRepo.save(date);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @DeleteMapping("/date")
    public ResponseEntity<String> deleteDate(
        @RequestParam(value="id") Long id,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can delete a date", HttpStatus.FORBIDDEN);
        }

        dateRepo.deleteById(id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }
}
