package com.supertravel.Application.controller;

import com.supertravel.Application.model.Category;
import com.supertravel.Application.model.User;
import com.supertravel.Application.repository.CategoryRepo;
import com.supertravel.Application.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@Controller
public class CategoryController {
    @Autowired
    CategoryRepo categoryRepo;
    @Autowired
    UserRepo userRepo;

    @GetMapping("/category")
    public ResponseEntity<List<Category>> getCategories() {
        Iterable<Category> iterable = categoryRepo.findAll();
        List<Category> list = Streamable.of(iterable).toList();

        return new ResponseEntity<List<Category>>(list, HttpStatus.OK);
    }

    @GetMapping("/category/{id}")
    public ResponseEntity<Category> getCategory(@PathVariable(value="id") Long id) {
        Optional<Category> category = categoryRepo.findById(id);
        if (category.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        return new ResponseEntity<Category>(category.get(), HttpStatus.OK);
    }

    @PostMapping("/category")
    public ResponseEntity<String> createCategory(@RequestBody Category category, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can create new category", HttpStatus.FORBIDDEN);
        }

        categoryRepo.save(category);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }


    @PutMapping("/category")
    public ResponseEntity<String> updateCategory(
        @RequestBody Category category,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can update a category", HttpStatus.FORBIDDEN);
        }

        if (category.id == null) {
            return new ResponseEntity<>("no category id provided", HttpStatus.BAD_REQUEST);
        }

        categoryRepo.save(category);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @DeleteMapping("/category")
    public ResponseEntity<String> deleteCategory(
        @RequestParam(value="id") Long id,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can delete a category", HttpStatus.FORBIDDEN);
        }

        categoryRepo.deleteById(id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }
}
