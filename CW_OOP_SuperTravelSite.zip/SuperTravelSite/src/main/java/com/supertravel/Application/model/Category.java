package com.supertravel.Application.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "category")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    public String title;
    public String pictureUrl;
    @Column(length=512)
    public String description;

    @OneToMany(mappedBy = "category")
    private Set<Trip> trips;
}
