package com.supertravel.Application.controller;

import com.supertravel.Application.model.Country;
import com.supertravel.Application.model.User;
import com.supertravel.Application.repository.CountryRepo;
import com.supertravel.Application.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;

@Controller
public class CountryController {
    @Autowired
    CountryRepo countryRepo;
    @Autowired
    UserRepo userRepo;

    @GetMapping("/country")
    public ResponseEntity<List<Country>> getCountries() {
        Iterable<Country> iterable = countryRepo.findAll();
        List<Country> list = Streamable.of(iterable).toList();

        return new ResponseEntity<List<Country>>(list, HttpStatus.OK);
    }

    @GetMapping("/country/{id}")
    public ResponseEntity<Country> getCountry(@PathVariable(value="id") Long id) {
        Optional<Country> data = countryRepo.findById(id);
        if (data.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        Country country = data.get();

        return new ResponseEntity<Country>(country, HttpStatus.OK);
    }

    @PostMapping("/country")
    public ResponseEntity<String> createCountry(@RequestBody Country country, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can create new country", HttpStatus.FORBIDDEN);
        }

        System.out.println(country.id + " " + country.description + " " + country.title);

        countryRepo.save(country);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }


    @PutMapping("/country")
    public ResponseEntity<String> updateCountry(
        @RequestBody Country country,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can update a country", HttpStatus.FORBIDDEN);
        }

        if (country.id == null) {
            return new ResponseEntity<>("no country id provided", HttpStatus.BAD_REQUEST);
        }

        countryRepo.save(country);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @DeleteMapping("/country")
    public ResponseEntity<String> deleteCountry(
        @RequestParam(value="id") Long id,
        HttpSession session
    ) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (user.userGroup != User.Group.ADMINISTRATOR) {
            return new ResponseEntity<>("only administrator can delete a country", HttpStatus.FORBIDDEN);
        }

        countryRepo.deleteById(id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }
}
