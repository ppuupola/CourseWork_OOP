package com.supertravel.Application.repository;

import com.supertravel.Application.model.Date;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DateRepo extends JpaRepository<Date, Long> {}
