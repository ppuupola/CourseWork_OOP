package com.supertravel.Application.controller;

import com.supertravel.Application.model.User;
import com.supertravel.Application.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpSession;

class SignInRequest {
    public String email;
    public String password;
}

class ChangePasswordRequest {
    public String oldPassword;
    public String newPassword;
}

@Controller
public class UserController {
    @Autowired
    UserRepo userRepo;

    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    @PostMapping("/user/signin")
    public ResponseEntity<String> signIn(@RequestBody SignInRequest request, HttpSession session) {
        User user = userRepo.findFirstByEmail(request.email);
        if (user == null) {
            return new ResponseEntity<>("user not found", HttpStatus.BAD_REQUEST);
        }

        if (encoder.matches(request.password, user.password)) {
            session.setAttribute("user", user.id);
        } else {
            return new ResponseEntity<>("wrong credentials", HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<String>("ok", HttpStatus.OK);
    }

    @PostMapping("/user/signup")
    public ResponseEntity<String> signUp(@RequestBody User request, HttpSession session) {
        if (request.password.length() < 8) {
            return new ResponseEntity<>("password is too weak", HttpStatus.BAD_REQUEST);
        }

        request.password = encoder.encode(request.password);
        request.userGroup = User.Group.USER;
        User user = userRepo.save(request);

        session.setAttribute("user", user.id);

        return new ResponseEntity<>("ok", HttpStatus.CREATED);
    }

    @PostMapping("/user/password")
    public ResponseEntity<String> changePassword(@RequestBody ChangePasswordRequest request, HttpSession session) {
        Long userId = (Long) session.getAttribute("user");
        if (userId == null) {
            return new ResponseEntity<>("not authorized", HttpStatus.FORBIDDEN);
        }

        User user = userRepo.findById(userId).get();

        if (encoder.matches(request.oldPassword, user.password)) {
            return new ResponseEntity<>("invalid old password", HttpStatus.BAD_REQUEST);
        }

        if (request.newPassword.length() < 8) {
            return new ResponseEntity<>("password is too weak", HttpStatus.BAD_REQUEST);
        }

        user.password = encoder.encode(request.newPassword);

        userRepo.save(user);

        return new ResponseEntity<>("ok", HttpStatus.OK);
    }
}
